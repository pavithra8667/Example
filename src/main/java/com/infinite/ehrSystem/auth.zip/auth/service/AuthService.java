package com.infinite.ehrSystem.auth.service;

import com.infinite.ehrSystem.auth.dto.AuthDTO;
import com.infinite.ehrSystem.auth.entity.User;
import com.infinite.ehrSystem.auth.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public AuthDTO login(AuthDTO authDTO) {

        User user = userRepository
                .findByUsername(authDTO.getUsername())
                .orElseThrow(() ->
                        new RuntimeException("Invalid username or password"));

        if (!passwordEncoder.matches(
                authDTO.getPassword(),
                user.getPassword())) {

            throw new RuntimeException("Invalid username or password");
        }

        String role = user.getRole().getName();

        String token = jwtService.generateToken(
                user.getUsername(),
                role);

        AuthDTO response = new AuthDTO();
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        response.setRole(role);
        response.setToken(token);

        return response;
    }
}
