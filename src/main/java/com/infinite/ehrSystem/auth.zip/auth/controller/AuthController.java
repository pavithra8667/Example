package com.infinite.ehrSystem.auth.controller;

import com.infinite.ehrSystem.auth.dto.AuthDTO;
import com.infinite.ehrSystem.auth.service.AuthService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthDTO> login(
            @Valid @RequestBody AuthDTO authDTO) {

        AuthDTO response = authService.login(authDTO);

        return ResponseEntity.ok(response);
    }
}